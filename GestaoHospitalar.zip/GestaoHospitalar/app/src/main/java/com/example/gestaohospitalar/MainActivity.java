package com.example.gestaohospitalar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

public class MainActivity extends AppCompatActivity {

    Button btnNovo;
    ListView listViewUnidades;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnNovo = (Button) findViewById(R.id.btnNovo);
        listViewUnidades = (ListView) findViewById(R.id.listviewUnidades);

        this.listarUnidades();

    }

    private void listarUnidades(){

        //Testar URL com IP do host se não funcionar o local

        String URL = "https://pacific-ravine-94784.herokuapp.com/unidades";

        Ion.with(MainActivity.this).load(URL).asJsonArray().setCallback(new FutureCallback<JsonArray>() {
            @Override
            public void onCompleted(Exception e, JsonArray result) {

                try{

                    for (int i=0; i < result.size(); i++){

                        JsonObject uni = result.get(i).getAsJsonObject(); //Cada unidade vira um objeto

                        Log.d("Unidade", uni.get("name").getAsString());
                    }
                    //Se não conseguir acessar o Json exibe o erro

                }catch (Exception erro){
                    Toast.makeText(MainActivity.this, "Erro ao Listar", Toast.LENGTH_SHORT).show();
                }

            }
        });



    }
}
